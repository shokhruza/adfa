
from pathlib import Path
from os.path import join



# def add_balance(summ):
#     print("run function")
#
# if __name__ == "__main__":
#     print(__file__)
#     print(__name__)
#     add_balance(10000)



