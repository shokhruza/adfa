from load import *
from pause import *
from play import *