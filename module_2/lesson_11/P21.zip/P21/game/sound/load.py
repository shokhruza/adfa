
def function_sound():
    pass