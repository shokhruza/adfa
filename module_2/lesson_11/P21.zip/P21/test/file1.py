

def add_str(*args):
    return "".join(args)