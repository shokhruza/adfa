def function():
    pass