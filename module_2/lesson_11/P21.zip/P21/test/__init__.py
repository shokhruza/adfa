from test.calculator import *
from test.file1 import *
from test.file2 import *