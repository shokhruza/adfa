# import sys
# sys.path.append('/home/dilshod/PycharmProjects/P21/dir1')
# from main1 import add

# print(add(1, 2, 3, 4, 5))