
def add(*args):
    return sum(args)