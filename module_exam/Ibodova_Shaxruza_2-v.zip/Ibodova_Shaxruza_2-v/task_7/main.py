import logging

logging.DEBUG('send_info.log')